#!/bin/sh

curl -O http://datasets.d2.mpi-inf.mpg.de/deepercut-models/ResNet-152.caffemodel
