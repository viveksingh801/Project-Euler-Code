<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('try',function(){
	return (response()->download('qz'));
	echo (app_path().' '.public_path().' '.storage_path());
	echo "\n";
	//echo(File::get('js/app.js'));
	
	echo(url('/')."/public".'/qz');

	dd(file_exists(public_path().'/js/app.js'));
});

// Route::get('convert',function(){
// 	FFMpeg::fromDisk('local')
//     ->open('qz')
//     ->export()
//     ->toDisk('local')
//     ->inFormat(new \FFMpeg\Format\Video\WMV3)
//     ->save('yesterday.WMV3');
// });


Route::get('public/{id}',function($id){
	return (response()->download($id.'.wmv'));

});


use Illuminate\Http\Request; 
Route::post('blobConvert',function(Request $request){
	if(empty($request->blob)){
	      	dd("It's Empty Baby");
	      }
	      else{
	      	$image= (uniqid());
	      	$request->blob->move(
                   base_path().'/public/',$image);
	      		$url=url('/')."/public/".$image;
	}


	//$ffmpeg = FFMpeg\FFMpeg::create();


	$ffmpeg = FFMpeg\FFMpeg::create(array(
		    'ffmpeg.binaries'  => 'C:/Users/vivek/Downloads/v/bin/ffmpeg.exe',
		    'ffprobe.binaries' => 'C:/Users/vivek/Downloads/v/bin/ffprobe.exe',
		    'timeout'          => 3600, // The timeout for the underlying process
		    'ffmpeg.threads'   => 12,   // The number of threads that FFMpeg should use
	));



	$video = $ffmpeg->open($image);
	$video -> save(new FFMpeg\Format\Video\X264(), $image.'.wmv');
	return ($url);





/*
	$ffmpeg = FFMpeg\FFMpeg::create(array(
    'ffmpeg.binaries'  => 'C:/Users/vivek/Downloads/v/bin/ffmpeg.exe',
    'ffprobe.binaries' => 'C:/Users/vivek/Downloads/v/bin/ffprobe.exe',
    'timeout'          => 3600, // The timeout for the underlying process
    'ffmpeg.threads'   => 12,   // The number of threads that FFMpeg should use
));
	$video = $ffmpeg->open('qz');
	$video
    // ->save(new FFMpeg\Format\Video\X264(), 'export-x264.mp4')
    ->save(new FFMpeg\Format\Video\WMV(), 'export-wmv.wmv');
    //->save(new FFMpeg\Format\Video\WebM(), 'export-webm.webm');


 */
});